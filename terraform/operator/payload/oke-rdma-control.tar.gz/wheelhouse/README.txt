No vendored wheels in this development payload. build-orm.sh vendors them by default.
